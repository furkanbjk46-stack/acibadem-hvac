#!/bin/bash
echo ''
echo '===================================================='
echo '   ACIBADEM HVAC - ENERJI PORTAL - KURULUM (Linux)'
echo '===================================================='
echo ''
if ! command -v python3 >/dev/null 2>&1; then
    echo '[HATA] python3 bulunamadi! Kurun: sudo apt install python3 python3-pip'
    exit 1
fi
echo "[OK] Python3: $(python3 --version)"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"
SUB=$(ls -d */ 2>/dev/null | head -1)
if [ -z "$SUB" ]; then echo "[HATA] Alt klasor bulunamadi."; exit 1; fi
cd "$SUB"
echo "Klasor: $(pwd)"
python3 -m pip install --upgrade pip --quiet
echo 'Kutuphaneler yukleniyor (requirements.txt)...'
python3 -m pip install -r requirements.txt --quiet
if [ $? -ne 0 ]; then echo '[HATA] Yukleme basarisiz!'; exit 1; fi
echo '[OK] Tum kutuphaneler yuklendi!'
echo ''
echo 'Portali baslatmak icin: python3 portal_watchdog.py'
