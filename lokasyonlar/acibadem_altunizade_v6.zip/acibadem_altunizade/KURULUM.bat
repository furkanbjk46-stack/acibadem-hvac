@echo off
chcp 65001 >nul
title ACIBADEM Portal Kurulum
color 0B
echo.
echo ====================================================
echo    ACIBADEM HVAC ^& ENERJI PORTAL - KURULUM
echo ====================================================
echo.
python --version >nul 2>&1
if errorlevel 1 (
    echo [HATA] Python bulunamadi!
    echo Python: https://www.python.org/downloads/
    echo Kurulumda Add Python to PATH secenegini isaretleyin.
    pause
    exit /b 1
)
echo [OK] Python bulundu.
echo.
cd /d "%~dp0"
cd altunizade
echo Kutuphaneler yukleniyor (requirements.txt)...
echo.
python -m pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo [HATA] Kutuphane yukleme basarisiz!
    pause
    exit /b 1
)
echo.
echo [OK] Tum kutuphaneler yuklendi!
echo.
set DESKTOP=%USERPROFILE%\Desktop
set SHORTCUT_NAME=HVAC Portal.lnk
set BAT_PATH=%~dp0PORTAL_BASLAT.bat
powershell -Command "$WS = New-Object -ComObject WScript.Shell; $SC = $WS.CreateShortcut('%DESKTOP%\%SHORTCUT_NAME%'); $SC.TargetPath = '%BAT_PATH%'; $SC.WorkingDirectory = '%~dp0'; $SC.IconLocation = 'shell32.dll,21'; $SC.Description = 'HVAC ve Enerji Portal Sistemi'; $SC.Save()"
echo.
echo ====================================================
echo    KURULUM TAMAMLANDI!
echo ====================================================
echo.
pause
