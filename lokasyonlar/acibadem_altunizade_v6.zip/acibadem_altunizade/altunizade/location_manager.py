# location_manager.py
# Tek lokasyon yonetimi -- Altunizade

from __future__ import annotations
import os
import json
import logging
from typing import Dict

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

LOCATION_CONFIG = {
    "id": "altunizade",
    "name": "Acibadem Altunizade Hastanesi",
    "short_name": "Altunizade",
    "is_master": False,
    "energy_schema": {
        "single_labels": {
            "heating_temp": "Isitma Temp",
            "boiler_temp": "Kazan Temp",
            "cooling_temp": "Sogutma Temp"
        }
    },
    "csv_columns": {
        "heating_temp_cols": [
            "Isitma_Temp_C", "Kazan_Temp_C", "Sogutma_Temp_C"
        ]
    }
}


class LocationManager:
    """Tek lokasyon yonetimi."""

    def get_active_location_id(self) -> str:
        return "altunizade"

    def list_locations(self) -> list:
        return [LOCATION_CONFIG]

    def get_location_config(self, location_id: str = None) -> Dict:
        return LOCATION_CONFIG

    def get_location_dir(self, location_id: str = None) -> str:
        return BASE_DIR

    def get_data_path(self, filename: str, location_id: str = None) -> str:
        return os.path.join(BASE_DIR, filename)

    def ensure_locations_ready(self):
        pass


_manager = None

def get_manager() -> LocationManager:
    global _manager
    if _manager is None:
        _manager = LocationManager()
    return _manager
